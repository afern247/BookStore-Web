# =====================================================
# CODE AUTHOR: RAUL ESPINOSA
# The bookDetails app config file.
# =====================================================

from django.apps import AppConfig

class BookDetailsConfig(AppConfig):
    name = "bookDetails"