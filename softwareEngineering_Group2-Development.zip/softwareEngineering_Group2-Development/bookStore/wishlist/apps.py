from django.apps import AppConfig


class WishlistConfig(AppConfig):
    name = 'wishlist'
