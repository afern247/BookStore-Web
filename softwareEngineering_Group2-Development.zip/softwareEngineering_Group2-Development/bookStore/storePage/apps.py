from django.apps import AppConfig


class StorepageConfig(AppConfig):
    name = 'storePage'
